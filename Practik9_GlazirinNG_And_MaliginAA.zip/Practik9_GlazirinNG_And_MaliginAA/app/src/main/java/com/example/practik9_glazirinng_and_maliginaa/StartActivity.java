package com.example.practik9_glazirinng_and_maliginaa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class StartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
    }

    public void goToChats(View view){
        Intent intent = new Intent(this, StepsActivity.class);
        startActivity(intent);
    }
}